from django.apps import AppConfig


class SentimentOrEmotionConfig(AppConfig):
    name = 'sentiment_or_emotion'
